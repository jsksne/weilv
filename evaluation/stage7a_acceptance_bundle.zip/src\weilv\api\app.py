"""Minimal Stage 5 FastAPI application over the frozen Python core."""

import os
from contextlib import asynccontextmanager
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

from elasticsearch import ApiError, Elasticsearch
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware

from weilv.agentic_rag import run_agentic_rag
from weilv.api.schemas import (
    AgenticRecommendationResponse,
    ProfileRequest,
    ProfileResponse,
    RecommendationRequest,
    RecommendationResponse,
    TaskFeedbackRequest,
    TaskFeedbackResponse,
)
from weilv.basic_rag import BasicRagRequest
from weilv.elasticsearch_indices import ensure_stage_one_indices, ensure_user_memory_indices
from weilv.interaction_logs import (
    create_recommendation_log,
    get_recommendation_log,
    update_recommendation_feedback,
)
from weilv.personal_memory_retrieval import embed_memory
from weilv.personal_rag import run_personal_rag
from weilv.retrieval_slice import _env_value, load_api_key
from weilv.user_memory import (
    UserMemoryCandidate,
    UserProfile,
    build_memory_id,
    create_memory,
    get_user_profile,
    update_memory,
    upsert_user_profile,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@asynccontextmanager
async def lifespan(application: FastAPI):
    env_file = PROJECT_ROOT / ".env"
    es_url = _env_value("ELASTICSEARCH_URL", env_file) or "http://127.0.0.1:9200"
    application.state.es_client = Elasticsearch(es_url, request_timeout=30)
    try:
        ensure_stage_one_indices(application.state.es_client)
        ensure_user_memory_indices(application.state.es_client)
        try:
            application.state.api_key = load_api_key(env_file)
        except RuntimeError:
            application.state.api_key = None
        yield
    finally:
        application.state.es_client.close()


app = FastAPI(title="Weilv API", version="1.0.0", lifespan=lifespan)
origins = [
    value.strip()
    for value in os.getenv("WEILV_CORS_ORIGINS", "http://localhost:5173").split(",")
    if value.strip() and value.strip() != "*"
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT"],
    allow_headers=["Content-Type"],
)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


def _dependency(request: Request, name: str):
    value = getattr(request.app.state, name, None)
    if value is None:
        raise HTTPException(status_code=503, detail="api_not_configured")
    return value


@app.post(
    "/api/v1/recommendations",
    response_model=RecommendationResponse,
)
def recommendations(payload: RecommendationRequest, request: Request):
    rag_request = BasicRagRequest(**payload.model_dump(exclude={"user_id"}))
    try:
        result = run_personal_rag(
            rag_request,
            payload.user_id,
            _dependency(request, "es_client"),
            _dependency(request, "api_key"),
        )
    except HTTPException:
        raise
    except Exception as error:
        raise HTTPException(status_code=503, detail="dependency_service_unavailable") from error
    result = dict(result)
    result.update(recommendation_id=None, feedback_available=False)
    if result.get("status") != "allowed" or not result.get("selected_task"):
        return result

    recommendation_id = str(uuid4())
    session = {
        "recommendation_id": recommendation_id,
        "user_id": payload.user_id,
        "status": result["status"],
        "selected_task_id": result["selected_task"]["task_id"],
        "target_stage": payload.target_stage,
        "current_context": payload.current_context,
        "activity_context": payload.activity_context,
        "available_minutes": payload.available_minutes,
        "created_at": datetime.now(UTC).isoformat(),
        "feedback": None,
        "feedback_updated_at": None,
        "memory_persisted": False,
    }
    try:
        create_recommendation_log(_dependency(request, "es_client"), session)
    except (ApiError, RuntimeError, ValueError):
        return result
    result.update(recommendation_id=recommendation_id, feedback_available=True)
    return result


@app.post(
    "/api/v1/recommend/agentic",
    response_model=AgenticRecommendationResponse,
)
def agentic_recommendation(payload: RecommendationRequest, request: Request):
    rag_request = BasicRagRequest(**payload.model_dump(exclude={"user_id"}))
    try:
        result = run_agentic_rag(
            rag_request,
            payload.user_id,
            _dependency(request, "es_client"),
            _dependency(request, "api_key"),
        )
    except HTTPException:
        raise
    except Exception as error:
        raise HTTPException(status_code=503, detail="dependency_service_unavailable") from error
    result = dict(result)
    result.update(recommendation_id=None, feedback_available=False)
    if result.get("status") != "allowed" or not result.get("selected_task"):
        return result

    recommendation_id = str(uuid4())
    diagnostics = result["diagnostics"]
    session = {
        "recommendation_id": recommendation_id,
        "user_id": payload.user_id,
        "status": result["status"],
        "selected_task_id": result["selected_task"]["task_id"],
        "target_stage": payload.target_stage,
        "current_context": payload.current_context,
        "activity_context": payload.activity_context,
        "available_minutes": payload.available_minutes,
        "agentic": True,
        "factor_count": diagnostics["factor_count"],
        "memory_hit": diagnostics["memory_hit_count"] > 0,
        "model_call_counts": diagnostics["model_calls"],
        "created_at": datetime.now(UTC).isoformat(),
        "feedback": None,
        "feedback_updated_at": None,
        "memory_persisted": False,
    }
    try:
        create_recommendation_log(_dependency(request, "es_client"), session)
    except (ApiError, RuntimeError, ValueError):
        return result
    result.update(recommendation_id=recommendation_id, feedback_available=True)
    return result


@app.put("/api/v1/users/{user_id}/profile", response_model=ProfileResponse)
def put_profile(user_id: str, payload: ProfileRequest, request: Request):
    client = _dependency(request, "es_client")
    try:
        existing = get_user_profile(client, user_id)
        now = datetime.now(UTC).isoformat()
        profile = UserProfile(
            user_id=user_id,
            target_stage=payload.target_stage,
            memory_enabled=payload.memory_enabled,
            created_at=existing.created_at if existing else now,
            updated_at=now,
        )
        upsert_user_profile(client, profile)
        return asdict(profile)
    except HTTPException:
        raise
    except Exception as error:
        raise HTTPException(status_code=503, detail="dependency_service_unavailable") from error


@app.get("/api/v1/users/{user_id}/profile", response_model=ProfileResponse)
def read_profile(user_id: str, request: Request):
    try:
        profile = get_user_profile(_dependency(request, "es_client"), user_id)
    except HTTPException:
        raise
    except Exception as error:
        raise HTTPException(status_code=503, detail="dependency_service_unavailable") from error
    if profile is None:
        raise HTTPException(status_code=404, detail="profile_not_found")
    return asdict(profile)


def persist_task_feedback_memory(
    client,
    profile: UserProfile,
    candidate: UserMemoryCandidate,
    api_key: str | None,
) -> dict[str, bool]:
    memory_id = build_memory_id(candidate)
    candidate = UserMemoryCandidate(**{**asdict(candidate), "memory_id": memory_id})
    result = create_memory(client, profile, candidate, {candidate.task_id})
    if result["status"] == "already_exists":
        result = update_memory(client, profile, candidate, {candidate.task_id})
    memory_persisted = result["status"] in {"created", "updated"}
    embedding_ready = False
    if memory_persisted and api_key:
        try:
            embedding_ready = embed_memory(client, profile.user_id, memory_id, api_key)[
                "status"
            ] == "embedded"
        except (ApiError, RuntimeError, ValueError):
            embedding_ready = False
    return {
        "memory_persisted": memory_persisted,
        "memory_embedding_ready": embedding_ready,
    }


@app.post(
    "/api/v1/users/{user_id}/recommendations/{recommendation_id}/feedback",
    response_model=TaskFeedbackResponse,
)
def submit_task_feedback(
    user_id: str,
    recommendation_id: str,
    payload: TaskFeedbackRequest,
    request: Request,
):
    client = _dependency(request, "es_client")
    try:
        session = get_recommendation_log(client, user_id, recommendation_id)
    except Exception as error:
        raise HTTPException(status_code=503, detail="dependency_service_unavailable") from error
    if session is None or not session.get("selected_task_id"):
        raise HTTPException(status_code=404, detail="recommendation_not_found")

    now = datetime.now(UTC).isoformat()
    feedback = payload.model_dump()
    memory_persisted = False
    try:
        profile = get_user_profile(client, user_id)
        if profile is not None and profile.memory_enabled:
            candidate = UserMemoryCandidate(
                memory_id="",
                user_id=user_id,
                memory_type="task_feedback",
                source_type="structured_task_feedback",
                task_id=session["selected_task_id"],
                domain=None,
                memory_key="task_feedback",
                memory_value=feedback,
                created_at=now,
                updated_at=now,
            )
            memory_persisted = persist_task_feedback_memory(
                client,
                profile,
                candidate,
                getattr(request.app.state, "api_key", None),
            )["memory_persisted"]
        update_recommendation_feedback(
            client,
            recommendation_id,
            feedback,
            now,
            memory_persisted,
        )
    except HTTPException:
        raise
    except Exception as error:
        raise HTTPException(status_code=503, detail="dependency_service_unavailable") from error
    return {
        "status": "recorded",
        "recommendation_id": recommendation_id,
        "task_id": session["selected_task_id"],
        "memory_persisted": memory_persisted,
    }
