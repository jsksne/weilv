"""Fill the Stage 8 factor-coverage review from the recorded Agentic evidence.

Judgment basis (documented): the preregistration defines coverage as the
Agentic structured decomposition explicitly representing the substantive Gold
factor. Production exposes factor_count, factor_domains, the per-factor
knowledge retrieval trace and the served explanation, so the blinded review
uses those recorded artifacts. Memory_preference Gold factors are hidden from
the visible query by design (memory_query_leakage = 0), so they cannot be
represented in the query-based decomposition; they are handled by the memory
retrieval/personalization path and are recorded as NOT covered by the
structured decomposition.

This is a descriptive mechanism diagnostic only. It changes no metric, no
claim, no threshold and no production behavior.
"""

import csv
import json
from pathlib import Path

RUN_DIR = Path("evaluation/runs/20260818T020417Z_stage8_formal")
GOLD = Path("evaluation/datasets/agentic_complex_gold_frozen_v1_2.jsonl")

# Judgment map: case_id -> {gold_factor_position: (covered, evidence)}
JUDGMENT = {
    "AGX-001": {
        1: ("true", "F1(study_break): 连续用眼需休息"),
        2: ("true", "F2/F3 subquery time consideration; explanation '当前可用时间较短'"),
        3: ("true", "F3(sleep): explanation '后续睡眠准备'"),
        4: ("true", "F2(sedentary): explanation '倾向安静…无需强体力投入'"),
    },
    "AGX-002": {
        1: ("true", "F2(eye_health): 远眺缓解视疲劳"),
        2: ("true", "F3(physical_activity): 起身活动改善循环"),
        3: ("true", "F4: explanation '起身活动10分钟'"),
    },
    "AGX-003": {
        1: ("true", "F1(eye_health): 屏幕距离修正"),
        2: ("false", "no explicit study-space context in recorded decomposition evidence"),
        3: ("true", "explanation '当前可用时间较短'"),
    },
    "AGX-004": {
        1: ("true", "F1(sedentary): 久坐后需活动"),
        2: ("true", "F2: explanation '课间离座…走出教室'"),
        3: ("true", "F3/F4: explanation '轻度活动…避免剧烈运动'"),
    },
    "AGX-005": {
        1: ("true", "F1(physical_activity): 久坐后需轻度活动"),
        2: ("false", "memory_preference hidden from query by design (leakage=0); handled by memory pipeline, not decomposition"),
        3: ("false", "memory_preference hidden from query by design (leakage=0); handled by memory pipeline, not decomposition"),
    },
    "AGX-006": {
        1: ("true", "F1(sedentary): 久坐用眼后需休息"),
        2: ("true", "explanation '且无需起身' (cannot_move constraint)"),
        3: ("true", "explanation '休息约10分钟'"),
    },
    "AGX-007": {
        1: ("true", "F1(sleep): 夜间减少高亮屏幕暴露"),
        2: ("true", "F1: explanation '已到就寝时间…卧姿'"),
        3: ("false", "no explicit 5-minute window in recorded decomposition evidence"),
        4: ("true", "explanation '处理认知任务' (must-finish screen action)"),
    },
    "AGX-008": {
        1: ("true", "F1(study_break): 连续学习后需休息"),
        2: ("true", "F2(sleep): '避免兴奋影响入睡…睡前安静过渡'"),
        3: ("false", "memory_preference hidden from query by design (leakage=0); handled by memory pipeline, not decomposition"),
    },
    "AGX-009": {
        1: ("true", "F2(eye_health): 远眺缓解眼肌紧张"),
        2: ("true", "F3(physical_activity): 轻微活动改善循环"),
        3: ("true", "F1/F4: explanation '10分钟组合休息' (combined rest)"),
        4: ("true", "explanation '10分钟组合休息'"),
    },
    "AGX-010": {
        1: ("true", "F1(eye_health): 屏幕距离修正"),
        2: ("true", "explanation '机房环境允许立即微调'"),
        3: ("true", "explanation '当前可用时间较短'"),
    },
    "AGX-011": {
        1: ("true", "F1(sleep): 保持规律作息"),
        2: ("true", "F1/F4: explanation '已到固定睡觉时间'"),
        3: ("false", "memory_preference hidden from query by design (leakage=0); handled by memory pipeline, not decomposition"),
        4: ("true", "explanation '刷手机习惯易干扰入睡'"),
    },
    "AGX-012": {
        1: ("true", "F1(light_recovery): 光线暗弱伤眼"),
        2: ("true", "explanation '晚间学习时台灯与顶灯同开'"),
        3: ("false", "no explicit 2-minute window in recorded decomposition evidence"),
    },
    "AGX-013": {
        1: ("true", "F1(study_break): 连续阅读后休息"),
        2: ("true", "F2(outdoor): explanation '阳台或楼下均满足户外条件'"),
        3: ("false", "memory_preference hidden from query by design (leakage=0); handled by memory pipeline, not decomposition"),
    },
    "AGX-014": {
        1: ("true", "F1(sleep): 周末起床时间偏差"),
        2: ("true", "explanation '周末大幅推迟起床'"),
        3: ("true", "explanation '周末大幅推迟起床易扰乱节律' (sleep-in preference)"),
    },
    "AGX-015": {
        1: ("true", "F1(eye_health): 连续用眼视疲劳"),
        2: ("false", "memory_preference hidden from query by design (leakage=0); handled by memory pipeline, not decomposition"),
        3: ("false", "no explicit ease-to-sustain preference in recorded decomposition evidence"),
    },
    "AGX-016": {
        1: ("true", "F1(study_break): 连续读写后需休息"),
        2: ("false", "no explicit outdoor-unavailable context in recorded decomposition evidence"),
        3: ("false", "no explicit indoor-only movement preference in recorded decomposition evidence"),
    },
    "AGX-017": {
        1: ("true", "F1(eye_health): 屏幕距离修正"),
        2: ("true", "explanation '当前可用时间较短'"),
        3: ("false", "memory_preference hidden from query by design (leakage=0); handled by memory pipeline, not decomposition"),
    },
    "AGX-018": {
        1: ("true", "F1(sedentary): 娱乐久坐需中断"),
        2: ("true", "explanation '起身活动约10分钟'"),
        3: ("false", "memory_preference hidden from query by design (leakage=0); handled by memory pipeline, not decomposition"),
    },
    "AGX-019": {
        1: ("true", "F2(eye_health): 卧床阅读伤眼"),
        2: ("true", "explanation '已躺卧较久…卧床阅读'"),
        3: ("true", "explanation '先调整为坐姿再继续'"),
    },
    "AGX-020": {
        1: ("true", "F1/F3: 临睡卧姿用屏需纠正"),
        2: ("true", "F1/F2(sleep): 高亮屏抑制褪黑素、临睡用屏"),
        3: ("false", "no explicit 5-minute window in recorded decomposition evidence"),
        4: ("false", "memory_preference hidden from query by design (leakage=0); handled by memory pipeline, not decomposition"),
    },
}


def main() -> None:
    gold = [
        json.loads(line)
        for line in GOLD.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    records = [
        json.loads(line)
        for line in (RUN_DIR / "raw_results.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    agentic = {r["case_id"]: r for r in records if r["system"] == "agentic"}

    fields = (
        "case_id", "gold_factor_position", "gold_factor_type",
        "gold_factor_description", "agentic_factor_count",
        "agentic_factor_summary", "covered", "evidence",
    )
    rows = []
    for case in gold:
        if case["case_type"] != "task":
            continue
        record = agentic[case["case_id"]]
        diag = (record.get("result") or {}).get("agentic_diagnostics") or {}
        count = diag.get("factor_count") or 0
        domains = diag.get("factor_domains") or []
        summary = " | ".join(
            f"F{position}:{domain}" for position, domain in enumerate(domains, start=1)
        )
        judgment = JUDGMENT[case["case_id"]]
        for position, factor in enumerate(case["gold_required_factors"], start=1):
            covered, evidence = judgment[position]
            rows.append(
                {
                    "case_id": case["case_id"],
                    "gold_factor_position": position,
                    "gold_factor_type": factor["factor_type"],
                    "gold_factor_description": factor["description"],
                    "agentic_factor_count": count,
                    "agentic_factor_summary": summary,
                    "covered": covered,
                    "evidence": evidence,
                }
            )
    with (RUN_DIR / "factor_coverage_cases.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} factor-coverage rows")


if __name__ == "__main__":
    main()
