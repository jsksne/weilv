"""Stage 8 formal evaluator unit tests.

Covers: Gold-label leak guard, Gold Utility@1 scoring, Wilson CI, factor
coverage computation, memory alignment, and mechanical recomputation of
aggregate metrics from raw results.
"""

import json
import math

from evaluation.runners.run_stage8_formal_evaluation import (
    GOLD_ONLY_FIELDS,
    _memory_alignment,
    factor_coverage_metrics,
    input_hash,
    per_case_metrics,
    runtime_fields,
    system_metrics,
    wilson_ci,
)

GOLD_PATH = "evaluation/datasets/agentic_complex_gold_frozen_v1_2.jsonl"


def _load_gold():
    return [
        json.loads(line)
        for line in open(GOLD_PATH, encoding="utf-8").read().splitlines()
        if line.strip()
    ]


def _task_case():
    return {
        "case_id": "AGX-001",
        "case_type": "task",
        "query": "在家连续复习了四十多分钟，只想安静歇一下。",
        "target_stage": "primary_upper",
        "current_context": "home",
        "activity_context": "reading",
        "available_minutes": 10,
        "safety_flags": {
            "vision_abnormal": False,
            "physical_discomfort": False,
            "medical_request": False,
            "cannot_move": False,
            "unstable_environment": False,
            "sleep_being_crowded": False,
        },
        "preferred_task_ids": ["MT-BREAK-003"],
        "acceptable_task_ids": ["MT-BREAK-001"],
        "expected_status": "allowed",
        "gold_required_factors": [{"factor_type": "behavior_need", "description": "x"}],
        "gold_soft_preferences": ["prefers quiet rest"],
        "memory_enabled": False,
        "synthetic_memory_fixture": [],
    }


def test_runtime_fields_never_leak_gold_labels():
    for case in _load_gold():
        runtime = runtime_fields(case)
        assert not (GOLD_ONLY_FIELDS & set(runtime)), case["case_id"]
        assert "preferred_task_ids" not in runtime
        assert "gold_required_factors" not in runtime


def test_input_hash_is_deterministic_and_label_independent():
    case = _task_case()
    first = input_hash(case)
    assert first == input_hash(case)
    altered = {**case, "preferred_task_ids": ["MT-BREAK-001"]}
    assert input_hash(altered) == first


def _record(case_id, system, status="allowed", top1=None):
    return {
        "case_id": case_id,
        "case_type": "task",
        "system": system,
        "result": (
            {"status": status, "selected_task_id": top1, "sources": [], "explanation": ""}
            if status != "error"
            else None
        ),
        "error": status == "error",
    }


def test_utility_scoring():
    case = _task_case()
    # preferred top1 -> 2
    rows = per_case_metrics(
        [_record("AGX-001", "basic", top1="MT-BREAK-003")], [case]
    )
    assert rows[0]["utility"] == 2
    # acceptable top1 -> 1
    rows = per_case_metrics([_record("AGX-001", "basic", top1="MT-BREAK-001")], [case])
    assert rows[0]["utility"] == 1
    # invalid top1 -> 0
    rows = per_case_metrics([_record("AGX-001", "basic", top1="MT-EYE-001")], [case])
    assert rows[0]["utility"] == 0
    # non-allowed status -> 0 even if a task id is present
    rows = per_case_metrics(
        [_record("AGX-001", "basic", status="no_safe_task", top1=None)], [case]
    )
    assert rows[0]["utility"] == 0
    # error -> 0
    rows = per_case_metrics([_record("AGX-001", "basic", status="error")], [case])
    assert rows[0]["utility"] == 0


def test_wilson_ci():
    low, high = wilson_ci(20, 20)
    assert low > 0.8 and high == 1.0  # exact: ci converges to [~0.84, 1]
    low, high = wilson_ci(0, 20)
    assert low == 0.0 and high < 0.2


def test_factor_coverage_macro_micro_all_covered():
    gold = [
        {
            "case_id": "AGX-001",
            "case_type": "task",
            "gold_required_factors": [{"factor_type": "a"}, {"factor_type": "b"}],
        },
        {
            "case_id": "AGX-002",
            "case_type": "task",
            "gold_required_factors": [{"factor_type": "a"}],
        },
        {"case_id": "AGX-021", "case_type": "safety"},
    ]
    judgment = [
        {"case_id": "AGX-001", "gold_factor_position": 1, "covered": "true", "evidence": "F1"},
        {"case_id": "AGX-001", "gold_factor_position": 2, "covered": "false", "evidence": ""},
        {"case_id": "AGX-002", "gold_factor_position": 1, "covered": "true", "evidence": "F1"},
    ]
    coverage = factor_coverage_metrics(gold, judgment)
    assert coverage["macro_required_factor_coverage"] == (0.5 + 1.0) / 2
    assert coverage["micro_required_factor_coverage"] == 2 / 3
    assert coverage["all_factors_covered_rate"] == 1 / 2
    assert coverage["covered_factors_total"] == 2
    assert coverage["required_factors_total"] == 3
    low, high = coverage["all_factors_covered_wilson_95_ci"]
    assert 0 <= low <= high <= 1


def test_memory_alignment():
    case = {
        "case_type": "task",
        "memory_enabled": True,
        "synthetic_memory_fixture": [
            {
                "memory_type": "task_preference",
                "task_id": "MT-BREAK-001",
                "memory_value": {"preference": "prefer_task"},
            },
            {
                "memory_type": "task_feedback",
                "task_id": "MT-SED-001",
                "memory_value": {
                    "completion_status": "partially_completed",
                    "helpfulness": 2,
                    "burden": "hard",
                },
            },
        ],
    }
    aligned = _memory_alignment(
        {"error": False, "result": {"status": "allowed", "selected_task_id": "MT-BREAK-001"}},
        case,
    )
    assert aligned is True
    violated = _memory_alignment(
        {"error": False, "result": {"status": "allowed", "selected_task_id": "MT-SED-001"}},
        case,
    )
    assert violated is False


def test_aggregate_recomputed_from_raw():
    gold = [_task_case(), {**_task_case(), "case_id": "AGX-002", "memory_enabled": True,
        "synthetic_memory_fixture": [{"memory_type": "task_preference", "task_id": "MT-BREAK-001",
            "memory_value": {"preference": "prefer_task"}}]}]
    records = [
        _record("AGX-001", "basic", top1="MT-BREAK-003"),
        _record("AGX-001", "personal", top1="MT-BREAK-003"),
        _record("AGX-001", "agentic", top1="MT-BREAK-003"),
        _record("AGX-002", "basic", top1="MT-BREAK-003"),
        _record("AGX-002", "personal", top1="MT-BREAK-003"),
        _record("AGX-002", "agentic", top1="MT-BREAK-003"),
    ]
    rows = per_case_metrics(records, gold)
    metrics = system_metrics(rows, gold)
    for system in ("basic", "personal", "agentic"):
        utility = metrics[f"Gold Utility@1|{system}"]
        assert utility["denominator"] == 2
        assert utility["numerator"] == 4
        assert math.isclose(utility["value"], 2.0)


def test_all_24_frozen_cases_have_complete_runtime_partition():
    gold = _load_gold()
    assert len(gold) == 24
    for case in gold:
        runtime = runtime_fields(case)
        if case["case_type"] == "task":
            assert case["preferred_task_ids"]
            assert not (set(case["preferred_task_ids"]) & set(case["acceptable_task_ids"]))
